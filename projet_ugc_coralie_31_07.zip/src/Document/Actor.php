<?php

namespace App\Document;


class Actor { 
  public $liste = ['Tom Hanks', 'Brad Pitt' ,'Meryl Streep' ,'Leonardo DiCaprio'] ;
}